#ifndef ENTRADA_H
#define ENTRADA_H

#include "feria.h"

//POST: Solicita y retorna una accion valida de consola.
char recibir_accion();

bool desea_seguir_jugando();

#endif /* ENTRADA_H */