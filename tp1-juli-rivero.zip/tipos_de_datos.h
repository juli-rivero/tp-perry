#ifndef TIPO_DE_DATOS_H
#define TIPO_DE_DATOS_H

#define MAX_NOMBRE 20 //Para poder estelizar un caracter

typedef char styled_char[MAX_NOMBRE];

#endif /* TIPO_DE_DATOS_H */